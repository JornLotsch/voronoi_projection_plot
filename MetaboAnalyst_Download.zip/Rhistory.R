# PID of current job: 448810
mSet<-InitDataObjects("pktable", "mf", FALSE)
mSet<-SetDesignType(mSet, "multi")
mSet<-Read.TextDataTs(mSet, "Replacing_with_your_file_path", "colmf");
mSet<-ReadMetaData(mSet, Replacing_with_your_file_path);
mSet<-SanityCheckData(mSet)
mSet<-ReplaceMin(mSet);
mSet<-SanityCheckMeta(mSet, 1)
mSet<-SetDataTypeOfMeta(mSet);
mSet<-SanityCheckData(mSet)
mSet<-FilterVariable(mSet, "F", 25, "nrsd", 40, "median", 0)
mSet<-PreparePrenormData(mSet)
mSet<-Normalization(mSet, "MedianNorm", "NULL", "AutoNorm", ratio=FALSE, ratioNum=20)
mSet<-PlotNormSummary(mSet, "norm_0_", "png", 72, width=NA)
mSet<-PlotSampleNormSummary(mSet, "snorm_0_", "png", 72, width=NA)
mSet<-PCA.Anal(mSet)
mSet<-PlotPCAPairSummaryMeta(mSet, "pca_pair_meta_0_", "png", 72, width=NA, 5, "Diagnosis", "Gender")
mSet<-iPCA.Anal(mSet, "ipca_3d_0_.json", "Diagnosis", "Gender")
mSet<-SaveTransformedData(mSet)
